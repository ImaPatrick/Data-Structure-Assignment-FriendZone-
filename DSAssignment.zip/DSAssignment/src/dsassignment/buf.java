package dsassignment;

class buf {
    
}
